import React from "react";
import { useNavigate } from "react-router-dom";

export default function Logout() {
  const navigate = useNavigate();

  //handle logout
  function handleLogout() {
    //remove the user's authentication token from local storage
    localStorage.removeItem("token"); 

    //redirect user login page 
    navigate("/login"); 
  }

  return (
    <div>
      <h3>Logout</h3>
      <p>Are you sure you want to logout?</p>
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
}
